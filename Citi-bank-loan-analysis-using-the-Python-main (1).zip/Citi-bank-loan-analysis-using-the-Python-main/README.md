# Citi-bank-loan-analysis-using-the-Python
I always wanted to work with some finance dataset and finally I downloaded the case study of Citi bank from Kaggle platform, This case study was focused on using the EDA and then performing the data visualization task using various Python. Solving this case study will give us an idea about how real business problems are solved using EDA. 
